Samples in this folder are for the Pluralsight course, C# Collections, Module 6 - Lists, by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
AddToList: Demonstrates adding an item to a List<T>, and also creating a read-only-collection
ListCapacity: Demonstrates List<T> Capacity
NonBlankStringList: Demonstrates deriving from Collection<T> to create a customized list
ObservableCollection: Demonstrates catching collection changed events

