Samples in this folder are for the Pluralsight course, C# Collections, Module 3 - Inside Arrays
by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
BasicArrayOps: Demonstrates C# syntax for looking up and replacing elements, and enumerating elements, of an array
DeclareInitArray: Demonstrates in detail syntax for declaring and initializing arrays in C#
EnumerateArray: Compares using for and foreach to enumerate arrays
ForeachReadOnly: Demonstrates that you cannot replace array elements using foreach
ChangePerson: Demonstrates that you can modify a property on array elements using foreach
